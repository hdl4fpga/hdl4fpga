/*****************************************************************************
 * Primer ejemplo de programa para la EDU-CIAA
 * 
 * Funcionalidad: Encendido de un led, sin la utilizacion de librerias.
 *                Solo se trabaja con acceso directo a los registros de
 *                configuracion
 * 
 * Materia: Electronica Digital II - 2017 (ECyT - UNSAM)
 *
 * Documentacion:
 *    - UM10503 (LPC43xx ARM Cortex-M4/M0 multi-core microcontroller User
 *      Manual)
 *    - PINES UTILIZADOS DEL NXP LPC4337 JBD144 (Ing. Eric Pernia)
 *****************************************************************************/

#include "Encender_Led.h"

#define SCU_BASE				0x40086000	// Direccion del System Control Unit
#define	SFSP2_10				0x128		// Offset del registro de configurcion del pin

#define GPIO_BASE				0x400F4000	// Direccion del GPIO
#define	GPIO_PORT0_DIR_OFFSET	0x2000		// Offset del registro de direccion (DIR) del puerto 0
#define GPIO_PORT0_CLR_OFFSET	0x2280		// Offset del registro clear (CLR) del puerto 0
#define GPIO_PORT0_SET_OFFSET	0x2200		// Offset del registro set (SET) del puerto 0

void conf_GPIO(int *ptr){
	
	*ptr = (0x2 << 3) | (0x0);
	
}

int main(void) {
	
	int *ptr1 = (int *)((SCU_BASE)+(SFSP2_10));					// Direccion del registro de
																// conf. del pin P2_10 (GPIO0[14])
	int *ptr2 = (int *)((GPIO_BASE)+(GPIO_PORT0_DIR_OFFSET));	// Direccion del registro de
																// direccion del pin P2_10
	int *ptr3 = (int *)((GPIO_BASE)+(GPIO_PORT0_CLR_OFFSET));	// Direccion del registro de
																// clear del pin P2_10
	int *ptr4 = (int *)((GPIO_BASE)+(GPIO_PORT0_SET_OFFSET));	// Direccion del registro de
																// set del pin P2_10

	/***************************************************************************
	 * Configuracion del pin (LED1) como GPIO, con pull-up                     *
	 * (Registro de configuracion, pag 405 / Tabla 191)                        *
	 ***************************************************************************/
	// ADDRESS(SCU_BASE, SFSP2_10) = (SCU_MODE_EPUN | SCU_MODE_FUNC0);
	// SCU->SFSP[2][10] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P2_10, GPIO0[14], LED1
	//*ptr1 = (0x2 << 3) | (0x0);
	conf_GPIO(ptr1);

	/***************************************************************************
	 * Configuracion del pin (LED1) como salida (Registro de direccion,        *
	 * pag 455 -> Tabla 261)                                                   *
	 ***************************************************************************/
	// Calculo de la direccion del regitro DIR
	//     ptr2 = GPIO_BASE + GPIO_PORT0_DIR_OFFSET
	*ptr2 |= (1 << 14);
	
	/***************************************************************************
	 * Blanqueo del pin (LED1) (pag 456 -> Tabla 266)                          *
	 ***************************************************************************/
	// Calculo de la direccion del regitro CLR
	//     ptr3 = GPIO_BASE + GPIO_PORT0_CLR_OFFSET
	// *ptr3 |= (1 << 14);
	
	/***************************************************************************
	 * Encendido del led (LED1) (pag 456 -> Tabla 265)                         *
	 ***************************************************************************/
	// Calculo de la direccion del regitro SET
	//     ptr4 = GPIO_BASE + GPIO_PORT0_SET_OFFSET
	*ptr4 |= (1 << 14);

	
	while (1) {
	}

	return 0;
}