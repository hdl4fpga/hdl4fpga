// GPIO Register (General Purpose Input/Output)
typedef struct {				// Estructura para GPIO
	unsigned char B[128][32];	// Offset 0x0000: Byte pin registers ports 0 to n; pins PIOn_0 to PIOn_31 */
	int W[32][32];				// Offset 0x1000: Word pin registers port 0 to n
	int DIR[32];				// Offset 0x2000: Direction registers port n
	int MASK[32];				// Offset 0x2080: Mask register port n
	int PIN[32];				// Offset 0x2100: Portpin register port n
	int MPIN[32];				// Offset 0x2180: Masked port register port n
	int SET[32];				// Offset 0x2200: Write: Set register for port n Read: output bits for port n
	int CLR[32];				// Offset 0x2280: Clear port n
	int NOT[32];				// Offset 0x2300: Toggle port n
} GPIO_T;

// SCU Register (System Control Unit)
typedef struct {
	int  SFSP[16][32];		// Los pines digitales estan divididos en 16 grupos (P0-P9 y PA-PF)
	int  RESERVED0[256];
	int  SFSCLK[4];			// Pin configuration register for pins CLK0-3
	int  RESERVED16[28];
	int  SFSUSB;			// Pin configuration register for USB
	int  SFSI2C0;			// Pin configuration register for I2C0-bus pins
	int  ENAIO[3];			// Analog function select registers
	int  RESERVED17[27];
	int  EMCDELAYCLK;		// EMC clock delay register
	int  RESERVED18[63];
	int  PINTSEL[2];		// Pin interrupt select register for pin int 0 to 3 index 0, 4 to 7 index 1
} SCU_T;

#define GPIO_PORT_BASE		0x400F4000
#define SCU_BASE			0x40086000

#define GPIO_PORT			((GPIO_T *) GPIO_PORT_BASE)
#define SCU					((SCU_T *) SCU_BASE)


// Funcion y modo (pag. 413)
#define SCU_MODE_EPD			(0x0 << 3)		// habilita la resistencia de pull-down (deshabilita con 0)
#define SCU_MODE_EPUN			(0x0 << 4)		// habilita la resistencia de pull-up (deshabilita con 1)
#define SCU_MODE_DES			(0x2 << 3)		// deshabilita las resistencias de pull-down y pull-up
#define SCU_MODE_EHZ			(0x1 << 5)		// 1 Rapido (ruido medio con alta velocidad)
												// 0 Lento (ruido bajo con velocidad media)
#define SCU_MODE_EZI			(0x1 << 6)		// habilita buffer de entrada (deshabilita con 0)
#define SCU_MODE_ZIF_DIS		(0x1 << 7)		// deshabilita el filtro anti glitch de entrada (habilita con 1)

#define SCU_MODE_FUNC0			0x0				// seleccion de la funcion 0 del pin
#define SCU_MODE_FUNC1			0x1				// seleccion de la funcion 1 del pin
#define SCU_MODE_FUNC2			0x2				// seleccion de la funcion 2 del pin
#define SCU_MODE_FUNC3			0x3				// seleccion de la funcion 3 del pin
#define SCU_MODE_FUNC4			0x4				// seleccion de la funcion 4 del pin
#define SCU_MODE_FUNC5			0x5				// seleccion de la funcion 5 del pin

// Macro para el calculo de direcciones
//#define ADDRESS(x, offset) (*(volatile int *)(volatile char *) ((x)+(offset)))