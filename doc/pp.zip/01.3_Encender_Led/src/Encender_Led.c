/**********************************************************************************************
 * Endendido de un led en la placa EDU-CIAA, sin la utilizacion de librerias
 * Solo se trabaja con acceso directo a los registros de configuracion
 * 
 * Materia: Electronica Digital II - 2016 (UNSAM)
 *
 * Documentacion:
 *    - UM10503 (LPC43xx ARM Cortex-M4/M0 multi-core microcontroller User Manual)
 *    - PINES UTILIZADOS DEL NXP LPC4337 JBD144 (Ing. Eric Pernia)
 **********************************************************************************************/

#include "Encender_Led.h"

int main(void) {

	// Configuracion del pin (LED1) como GPIO, con pull-up
	// (Registro de configuracion, pag 405 / Tabla 191)
	// ADDRESS(SCU_BASE, SFSP2_10) = (SCU_MODE_EPUN | SCU_MODE_FUNC0);
	SCU->SFSP[2][10] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P2_10, GPIO0[14], LED1

	// Configuracion del pin (LED1) como salida (Registro de direccion, pag 455 -> Tabla 261)
	// ADDRESS(GPIO_BASE, GPIO_PORT0_DIR_OFFSET) |= (1 << 14);
	GPIO_PORT->DIR[0] |= 1 << 14;

	// Blanqueo del pin (LED1) (pag 456 -> Tabla 266)
	// ADDRESS(GPIO_BASE, GPIO_PORT0_CLR_OFFSET) |= (1 << 14);
//	GPIO_PORT->CLR[0] |= 1 << 14;
	
	// Encendido del led (LED1) (pag 456 -> Tabla 265)
	GPIO_PORT->SET[0] |= 1 << 14;

	
	while (1) {
	}

	return 0;
}