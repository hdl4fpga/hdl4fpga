/**********************************************************************************************
 * Endendido de un led en la placa EDU-CIAA, sin la utilizacion de librerias
 * Solo se trabaja con acceso directo a los registros de configuracion
 * 
 * Materia: Electronica Digital II - 2016 (UNSAM)
 *
 * Documentacion:
 *    - UM10503 (LPC43xx ARM Cortex-M4/M0 multi-core microcontroller User Manual)
 *    - PINES UTILIZADOS DEL NXP LPC4337 JBD144 (Ing. Eric Pernia)
 **********************************************************************************************/

#include "Encender_Led.h"

int main(void) {

	// Configuracion del pin (LED1) como GPIO, con pull-up
	// (Registro de configuracion, pag 405 / Tabla 191)
	// ADDRESS(SCU_BASE, SFSP2_10) = (SCU_MODE_EPUN | SCU_MODE_FUNC0);
	SCU->SFSP[2][10] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P2_10, GPIO0[14], LED1
	SCU->SFSP[1][11] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P2_11, GPIO1[11], LED2
	SCU->SFSP[1][12] = (SCU_MODE_DES | SCU_MODE_FUNC0); // P2_12, GPIO1[12], LED3

	SCU->SFSP[2][0] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_0, GPIO5[0], LEDR
	SCU->SFSP[2][1] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_1, GPIO5[1], LEDG
	SCU->SFSP[2][2] = (SCU_MODE_DES | SCU_MODE_FUNC4); // P2_2, GPIO5[2], LEDB
	
	// Configuracion del pin (LED1) como salida (Registro de direccion, pag 455 -> Tabla 261)
	// ADDRESS(GPIO_BASE, GPIO_PORT0_DIR_OFFSET) |= (1 << 14);
	GPIO_PORT->DIR[0] |= 1 << 14;
	GPIO_PORT->DIR[1] |= 1 << 11;
	GPIO_PORT->DIR[1] |= 1 << 12;

	GPIO_PORT->DIR[5] |= 1 << 0;
	GPIO_PORT->DIR[5] |= 1 << 1;
	GPIO_PORT->DIR[5] |= 1 << 2;

	// Blanqueo del pin (LED1) (pag 456 -> Tabla 266)
	// ADDRESS(GPIO_BASE, GPIO_PORT0_CLR_OFFSET) |= (1 << 14);
	GPIO_PORT->CLR[0] |= 1 << 14;
	GPIO_PORT->CLR[1] |= 1 << 11;
	GPIO_PORT->CLR[1] |= 1 << 12;
	
	// Encendido del led (LED1) (pag 456 -> Tabla 265)
	// ADDRESS(GPIO_BASE, GPIO_PORT0_SET_OFFSET) |= (1 << 14);
//	GPIO_PORT->SET[0] |= 1 << 14;
	
	// Sin utilizacion de la macro (para prender un led)
	// ptr = (int *)0x400F6200;	// 0x400F4000 + 0x2200 = 0x400F6200
	// *ptr |= (1 << 14); 

	
	while (1) {
	}

	return 0;
}