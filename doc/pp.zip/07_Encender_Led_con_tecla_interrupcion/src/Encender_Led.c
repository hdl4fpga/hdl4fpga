/**********************************************************************************************
 * Encendido de un led en la placa EDU-CIAA, al pulsar una tecla, mediante interrupciones
 * Solo se trabaja con acceso directo a los registros de configuracion
 * 
 * Materia: Electronica Digital II - 2016 (UNSAM)
 *
 * Documentacion:
 *    - UM10503 (LPC43xx ARM Cortex-M4/M0 multi-core microcontroller User Manual)
 *    - PINES UTILIZADOS DEL NXP LPC4337 JBD144 (Ing. Eric Pernia)
 **********************************************************************************************/

#include "Encender_Led.h"
#define LEDS_MASK		(SCU_MODE_DES | SCU_MODE_EZI)
#define BOTONES_MASK	(SCU_MODE_DES | SCU_MODE_EZI)

/*********************************************************************************************
 * Name		| Edge-sensitive function 					| Level-sensitive function
 * ------------------------------------------------------------------------------------------
 * IENR		| Enables rising-edge interrupts.			| Enables level interrupts.
 * SIENR	| Write to enable rising-edge interrupts.	| Write to enable level interrupts.
 * CIENR	| Write to disable rising-edge interrupts.	| Write to disable level interrupts.
 * IENF		| Enables falling-edge interrupts.			| Selects active level.
 * SIENF	| Write to enable falling-edge interrupts.	| Write to select high-active.
 * CIENF	| Write to disable falling-edge interrupts.	| Write to select low-active.
 *********************************************************************************************/

#define GPIO_PIN_INT_MASK		(1 << 0) | (1 << 1) | (1 << 2) | (1 << 3)

volatile bool bLed0Active = true ;
static char aux[256];	// para debugging (usada por printf)

void GPIO0_IRQHandler(void){
	GPIO_PIN_INT->IST = (1 << 0);

	bLed0Active = !bLed0Active;
	if (!bLed0Active)
		LED_OFF(LED1);
	else
		LED_ON(LED1);
}

void GPIO1_IRQHandler(void){
	GPIO_PIN_INT->IST = (1 << 1);
	bLed0Active = !bLed0Active ;
	if (!bLed0Active)
		LED_OFF(LED1);
	else
		LED_ON(LED1);
}

void GPIO2_IRQHandler(void){
	GPIO_PIN_INT->IST = (1 << 2);
	bLed0Active = !bLed0Active ;
	if (!bLed0Active)
		LED_OFF(LED1);
	else
		LED_ON(LED1);
}

void GPIO3_IRQHandler(void){
	GPIO_PIN_INT->IST = (1 << 3);
	bLed0Active = !bLed0Active ;
	if (!bLed0Active)
		LED_OFF(LED1);
	else
		LED_ON(LED1);
}

int main(void) {

	// Inicio de la UART para debugging
	UART_Init();
	
	// Configuracion de los leds y los botones
	Config_LEDS(LEDS_MASK);
	Config_Botones(BOTONES_MASK);
	
	SCU->PINTSEL[0] = 0;

	/* Configuracion del canal de interrupciones para los pines GPIO en el SCU                      *
	 * PINTSEL0 (0xE00): Registro para seleccionar la interrupcion (interrupciones de pin de 0 a 3) *
	 * PINTSEL1 (0xE04): Registro para seleccionar la interrupcion (interrupciones de pin de 4 a 7) */
	
	// SCU_GPIOIntPinSel(uint8_t PortSel, uint8_t PortNum, uint8_t PinNum)
	SCU_GPIOIntPinSel(0, 0, 4);	// TEC_1
	SCU_GPIOIntPinSel(1, 0, 8);	// TEC_2
	SCU_GPIOIntPinSel(2, 0, 9);	// TEC_3
	SCU_GPIOIntPinSel(3, 1, 9);	// TEC_4
	
	// **** Configuracion flanco ascendente y descendente
	GPIO_PIN_INT->ISEL &= ~GPIO_PIN_INT_MASK;	// Modo de la interrupcion (Tabla 246, pag. 457)
												// Flanco (0) , Nivel (1) 
	// GPIO_PIN_INT->IENR |= GPIO_PIN_INT_MASK;	// Habilitacion de las interrupciones por flanco ascendente
												// // Deshabilito (0) , Habilito (1)  (Tabla , pag. )
	// GPIO_PIN_INT->IENF |= GPIO_PIN_INT_MASK;	// Habilitacion de las interrupciones por flanco descendente
												// // Deshabilito (0) , Habilito (1)  (Tabla , pag. )

	GPIO_PIN_INT->SIENR = GPIO_PIN_INT_MASK;	// Habilitacion de las interrupciones por flanco ascendente
												// Deshabilito (0) , Habilito (1)  (Tabla , pag. )
	GPIO_PIN_INT->SIENF = GPIO_PIN_INT_MASK;	// Habilitacion de las interrupciones por flanco descendente
												// Deshabilito (0) , Habilito (1)  (Tabla , pag. )

	
	NVIC_SetPri(PIN_INT0_IRQn, 15);
	NVIC_SetPri(PIN_INT1_IRQn, 15);
	NVIC_SetPri(PIN_INT2_IRQn, 15);
	NVIC_SetPri(PIN_INT3_IRQn, 15);

	// Habilitacion de las interrupciones en el NVIC
	// _NVIC->ISER[1] = (unsigned int)(15 << 0);
	NVIC_EnaIRQ(PIN_INT0_IRQn);// _NVIC->ISER[1] = (unsigned int)(15 << 0);
	NVIC_EnaIRQ(PIN_INT1_IRQn);
	NVIC_EnaIRQ(PIN_INT2_IRQn);
	NVIC_EnaIRQ(PIN_INT3_IRQn);
	
	while (1) {
	}
	
	return 0;
}